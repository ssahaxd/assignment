for i in range(38):
    print("0"*11)
for i in range(2):
    print("0")


print("\x7c\n\x88\n\x04\n\x08")
print("\xb0\n\xe4\n\x04\n\x08")